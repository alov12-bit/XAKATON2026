import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, RotateCcw, Trophy, AlertCircle } from 'lucide-react';

type TrashType = 'plastic' | 'metal' | 'organic' | 'glass' | 'rubber';

interface TrashItem {
  id: number;
  type: TrashType;
  icon: string;
  x: number; // percentage 0-100
  y: number; // percentage 0-100
  speed: number;
  isDragging: boolean;
}

const BINS: { type: TrashType; label: string; color: string; border: string }[] = [
  { type: 'plastic', label: 'Пластик', color: 'bg-blue-500/20', border: 'border-blue-500' },
  { type: 'metal', label: 'Металл', color: 'bg-gray-500/20', border: 'border-gray-400' },
  { type: 'organic', label: 'Органика', color: 'bg-green-500/20', border: 'border-green-500' },
  { type: 'glass', label: 'Стекло', color: 'bg-teal-500/20', border: 'border-teal-500' },
  { type: 'rubber', label: 'Смешанное', color: 'bg-slate-700/20', border: 'border-slate-500' },
];

const TRASH_SPAWN_DATA = [
  { type: 'plastic', icons: ['🥤', '🧴', '🛍️'] },
  { type: 'metal', icons: ['🥫', '🔑', '🔩'] },
  { type: 'organic', icons: ['🍎', '🍌', '🍉'] },
  { type: 'glass', icons: ['🍾', '🍷', '🫙'] },
  { type: 'rubber', icons: ['🛞', '🩴', '🧤'] },
];

export default function Game() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [items, setItems] = useState<TrashItem[]>([]);
  
  const gameAreaRef = useRef<HTMLDivElement>(null);
  const binsRef = useRef<{ [key: string]: HTMLDivElement | null }>({});

  const startGame = () => {
    setIsPlaying(true);
    setGameOver(false);
    setScore(0);
    setLives(3);
    setItems([]);
  };

  useEffect(() => {
    if (!isPlaying || gameOver) return;

    const interval = setInterval(() => {
      setItems(prev => {
        const newItems = prev.map(item => {
          if (item.isDragging) return item;
          return { ...item, y: item.y + item.speed };
        });

        const missedItems = newItems.filter(item => item.y > 100);
        if (missedItems.length > 0) {
          setLives(l => {
            const newLives = l - missedItems.length;
            if (newLives <= 0) setGameOver(true);
            return newLives;
          });
        }

        return newItems.filter(item => item.y <= 100);
      });
    }, 50);

    return () => clearInterval(interval);
  }, [isPlaying, gameOver]);

  useEffect(() => {
    if (!isPlaying || gameOver) return;

    const spawnRate = Math.max(800, 2000 - score * 50);

    const interval = setInterval(() => {
      const randomCategory = TRASH_SPAWN_DATA[Math.floor(Math.random() * TRASH_SPAWN_DATA.length)];
      const randomIcon = randomCategory.icons[Math.floor(Math.random() * randomCategory.icons.length)];
      
      const newItem: TrashItem = {
        id: Date.now() + Math.random(),
        type: randomCategory.type as TrashType,
        icon: randomIcon,
        x: 10 + Math.random() * 80, 
        y: -10,
        speed: 0.5 + Math.random() * 0.5 + (score * 0.02), 
        isDragging: false,
      };

      setItems(prev => [...prev, newItem]);
    }, spawnRate);

    return () => clearInterval(interval);
  }, [isPlaying, gameOver, score]);

  const handleDragStart = (id: number) => {
    setItems(prev => prev.map(item => item.id === id ? { ...item, isDragging: true } : item));
  };

  const handleDragEnd = (e: any, info: any, item: TrashItem) => {
    const dropPoint = { x: info.point.x, y: info.point.y };
    let droppedInBin: TrashType | null = null;

    
    Object.entries(binsRef.current).forEach(([type, element]) => {
      if (element) {
        const rect = element.getBoundingClientRect();
        if (
          dropPoint.x >= rect.left &&
          dropPoint.x <= rect.right &&
          dropPoint.y >= rect.top &&
          dropPoint.y <= rect.bottom
        ) {
          droppedInBin = type as TrashType;
        }
      }
    });

    if (droppedInBin === item.type) {
      setScore(s => s + 10);
      setItems(prev => prev.filter(i => i.id !== item.id));
    } else if (droppedInBin) {
      setLives(l => {
        const newLives = l - 1;
        if (newLives <= 0) setGameOver(true);
        return newLives;
      });
      setItems(prev => prev.filter(i => i.id !== item.id));
    } else {
      setItems(prev => prev.map(i => i.id === item.id ? { ...i, isDragging: false } : i));
    }
  };

  return (
    <div className="h-[calc(100vh-80px)] bg-slate-900 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-sky-800 to-blue-950 opacity-80"></div>
      
      {!isPlaying && !gameOver && (
        <div className="relative z-10 bg-slate-800/90 backdrop-blur-md p-8 rounded-2xl border border-slate-600 shadow-2xl max-w-md text-center">
          <Trophy className="w-16 h-16 text-yellow-400 mx-auto mb-4" />
          <h2 className="text-3xl font-bold text-white mb-4">Очистим море</h2>
          <p className="text-slate-300 mb-6">
            Мусор падает в океан! Перетаскивай его в правильные контейнеры для переработки. 
            Не дай мусору упасть на дно и не перепутай контейнеры!
          </p>
          <button
            onClick={startGame}
            className="w-full bg-teal-500 hover:bg-teal-400 text-white font-bold py-4 px-8 rounded-xl text-xl transition-all hover:scale-105 flex items-center justify-center gap-2 shadow-lg shadow-teal-500/30"
          >
            <Play fill="currentColor" /> Начать игру
          </button>
        </div>
      )}

      {gameOver && (
        <div className="relative z-10 bg-slate-800/90 backdrop-blur-md p-8 rounded-2xl border border-rose-500/50 shadow-2xl max-w-md text-center">
          <AlertCircle className="w-16 h-16 text-rose-500 mx-auto mb-4" />
          <h2 className="text-3xl font-bold text-white mb-2">Игра окончена</h2>
          <p className="text-slate-300 mb-6">Океан слишком загрязнен...</p>
          <div className="text-5xl font-bold text-teal-400 mb-8">
            Счет: {score}
          </div>
          <button
            onClick={startGame}
            className="w-full bg-teal-500 hover:bg-teal-400 text-white font-bold py-4 px-8 rounded-xl text-xl transition-all hover:scale-105 flex items-center justify-center gap-2 shadow-lg shadow-teal-500/30"
          >
            <RotateCcw /> Играть снова
          </button>
        </div>
      )}

      {isPlaying && !gameOver && (
        <div className="relative z-10 w-full max-w-4xl h-full flex flex-col">
          {/* HUD */}
          <div className="flex justify-between items-center bg-slate-800/80 backdrop-blur-sm p-4 rounded-xl border border-slate-700 mb-4 shadow-lg">
            <div className="text-2xl font-bold text-white">
              Счет: <span className="text-teal-400">{score}</span>
            </div>
            <div className="flex gap-2">
              {[...Array(3)].map((_, i) => (
                <div 
                  key={i} 
                  className={`w-6 h-6 rounded-full ${i < lives ? 'bg-rose-500 shadow-[0_0_10px_rgba(244,63,94,0.8)]' : 'bg-slate-700'}`}
                />
              ))}
            </div>
          </div>

          <div 
            ref={gameAreaRef}
            className="flex-1 relative bg-blue-900/30 rounded-2xl border-2 border-dashed border-blue-400/30 overflow-hidden mb-4"
          >
            <AnimatePresence>
              {items.map(item => (
                <motion.div
                  key={item.id}
                  drag
                  dragMomentum={false}
                  onDragStart={() => handleDragStart(item.id)}
                  onDragEnd={(e, info) => handleDragEnd(e, info, item)}
                  initial={{ opacity: 0, scale: 0.5, x: 0, y: 0 }}
                  animate={{ 
                    opacity: 1, 
                    scale: 1,
                    x: item.isDragging ? undefined : 0,
                    y: item.isDragging ? undefined : 0,
                  }}
                  exit={{ opacity: 0, scale: 0 }}
                  transition={{ duration: item.isDragging ? 0 : 0.2 }}
                  style={{
                    position: 'absolute',
                    top: `${item.y}%`,
                    left: `${item.x}%`,
                    fontSize: '3rem',
                    cursor: 'grab',
                    touchAction: 'none',
                    zIndex: item.isDragging ? 50 : 10,
                  }}
                  className="active:cursor-grabbing drop-shadow-lg"
                >
                  {item.icon}
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          <div className="grid grid-cols-5 gap-2 md:gap-4 h-32">
            {BINS.map(bin => (
              <div
                key={bin.type}
                ref={el => binsRef.current[bin.type] = el}
                className={`${bin.color} border-2 ${bin.border} rounded-xl flex flex-col items-center justify-center p-2 backdrop-blur-md shadow-lg transition-transform hover:scale-105`}
              >
                <span className="text-xs md:text-sm font-bold text-white mb-1 text-center">{bin.label}</span>
                <div className="w-10 h-10 md:w-14 md:h-14 border-t-4 border-white/50 rounded-b-lg bg-black/20 flex items-center justify-center text-xl md:text-2xl">
                  {TRASH_SPAWN_DATA.find(d => d.type === bin.type)?.icons[0]}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
